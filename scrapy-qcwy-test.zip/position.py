# -*- coding: utf-8 -*-
import scrapy
import json
from urllib import parse
from qc_51job.items import QtwyJobInfoItem
from scrapy.loader import ItemLoader
from qc_51job import settings


class PositionSpider(scrapy.Spider):
    name = 'position'
    allowed_domains = ['51job.com', 'search.51job.com', 'jobs.51job.com']
    major = settings.JOB_MAJOR
    positions = parse.quote(parse.quote(major))        # 需要搜索的职位
    search_url = "https://search.51job.com/list/000000,000000,0000,00,9,99,{0},2,{1}.html{2}"
    params = "?lang=c&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&ord_field=0&dibiaoid=0&line=&welfare="
    start_urls = [search_url.format(positions, "1", params)]
    """
    以下操作都是在编写爬虫前，需要对所爬网站进行的分析
    https://search.51job.com/list/150200,000000,0000,00,9,99,%25E7%2588%25AC%25E8%2599%25AB,2,1.html?lang=c&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&ord_field=0&dibiaoid=0&line=&welfare=
    000000,000000,0000,00,9,99      =>  为城市参数，当前为全国
    %25E7%2588%25AC%25E8%2599%25AB  =>  对应搜索的职位名称，经过两次URL编译后得到
    2,1(最后面的2 和 1)               =>  2为固定参数；1为当前是第几页
    https://search.51job.com/list/000000,000000,0000,00,9,99,爬虫,2,1.html    =>  搜索全国的爬虫职位
    """

    def parse(self, response):
        json_str = response.text
        json_data = json.loads(json_str)
        for post in json_data.get('engine_search_result', []):
            position_name = post.get('job_name')
            salary = post.get('providesalary_text')
            enterprise_name = post.get('company_name')
            position_description = str(post.get('attribute_text'))
            source_url = post.get('job_href')
            yield scrapy.Request(source_url, meta={"position_name": position_name, "salary": salary,
                                                      "enterprise_name": enterprise_name,
                                                      "position_description": position_description,
                                                      "source_url": source_url},
                                 callback=self.parse_detail)
        # 下一页
        curr_page = int(json_data.get('curr_page'))
        total_page = int(json_data.get('total_page'))
        if curr_page == 1:
            pages = (i for i in range(2, total_page+1))
            for page in pages:
                next_url = self.search_url.format(self.positions, page, self.params)
                yield scrapy.Request(next_url, callback=self.parse)

    def parse_detail(self, response):
        item_loader = ItemLoader(item=QtwyJobInfoItem(), response=response)
        item_loader.add_value('position_name', response.meta.get("position_name"))
        item_loader.add_value('salary', response.meta.get("salary"))
        item_loader.add_value('enterprise_name', response.meta.get("enterprise_name"))
        item_loader.add_value('position_description', response.meta.get("position_description"))
        item_loader.add_value('source_url', response.meta.get("source_url"))
        item_loader.add_xpath('welfare', '//div[@class="jtag"]')
        item_loader.add_xpath('position_detail_description', '//div[@class="bmsg job_msg inbox"]')
        item_loader.add_xpath('contact_info', '//div[@class="bmsg inbox"]')
        item_loader.add_xpath('company_info', '//div[@class="tmsg inbox"]')
        yield item_loader.load_item()